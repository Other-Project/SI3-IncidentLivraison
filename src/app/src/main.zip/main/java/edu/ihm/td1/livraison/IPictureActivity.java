package edu.ihm.td1.livraison;

public interface IPictureActivity {
    int REQUEST_CAMERA = 100;
}
